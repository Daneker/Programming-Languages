from numbers import * 

def gcd( n1, n2 ) :   
    if( n1 < 0 or n2 < 0 ) :
       n1 = -n1

    if( n1 == 0 and n2 == 0 ) :
       raise ArithmeticError("gcd(0,0) does not exist")

    elif( n1 == 0 ) :
       return n2

    elif( n2 == 0 ) :
       return n1

    else :
       r = n1 % n2
       return gcd( n2, r )


class Rational( Number ) :
    def __init__( self, num, denum = 1 ) :
       self. num = num
       self. denum = denum
       self. normalize( )

    def normalize( self ) :
       if( self. denum < 0 ) :
           self. num = -self. num
           self. denum = -self. denum

       g = gcd( self. num, self. denum )
       if( g != 1 and g != -1) :
           self. num //= g
           self. denum //= g
       return self

    def __repr__( self ) : 
       if( self. denum == 1 ) :
           return "{}". format( self. num )
       elif( self. denum == 0 ) :
           raise ArithmeticError("error")
       else : 
           return "{} / {}". format( self. num, self. denum )

    def __neg__( self ) :
       return Rational( -self.num, self.denum )

    def __add__( self, other ) :
       if not isinstance( other, Rational ) :
           return Rational( self. num + other * self. denum, self. denum )  
       num = self. num * other. denum + other. num * self. denum
       denum = self. denum * other. denum
       return Rational( num, denum )
       
    def __sub__( self, other ) :
       if not isinstance( other, Rational ) :
           return Rational( self. num - other * self. denum, self. denum ) 
       num = self. num * other. denum - other. num * self. denum
       denum = self. denum * other. denum
       return Rational( num, denum )

    def __radd__( self, other ) :
       return self. __add__( other )

    def __rsub__( self, other ) :
       return (-self).__add__( other )

    def __mul__( self, other ) :
       if not isinstance( other, Rational ) :
           return Rational( self. num * other, self. denum )
       num = self. num * other. num
       denum = self. denum * other. denum
       return Rational( num, denum )

    def __truediv__( self, other ) :
       if not isinstance( other, Rational ) :
           return Rational( self. num, self. denum * other )
       num = self. num * other. denum
       denum = self. denum * other. num
       return Rational( num, denum )

    def __rmul__( self, other ) :
       return Rational( self. num * other, self. denum )

    def __rtruediv__( self, other ) :
       return Rational( self. denum * other, self. num )

