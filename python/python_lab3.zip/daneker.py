from matrix import *
from vector import *
from rational import *

def tests( ) :
    m1 = Matrix( Rational(1, 2), Rational(1, 3), Rational(-2, 7), Rational(2, 8) )
    m2 = Matrix( Rational(-1, 3), Rational(2, 7), Rational(2, 5), Rational(-1, 7) )
    m3 = Matrix( Rational(-1, 5), Rational(2, 3), Rational(1, 8), Rational(3, 11) )
    v = Vector(3, 4)


    print( "Matrix product of m1 and m2 is " )
    print( m1 @ m2, "\n" )

    print( "The inverse of m1 is " )
    print( m1.inverse(), "\n" )

    print( "Matrix multipication is associative " )
    print( ( ( m1 @ m2 ) @ m3 ) - ( m1 @ ( m2 @ m3 ) ), "\n" )

    print( "Matrix multipication with addition is distributive " )
    print( m1 @ ( m2 + m3 ) - ( m1 @ m2 + m1 @ m3 ) )
    print( ( m1 + m2 ) @ m3 - ( m1 @ m3 + m2 @ m3 ), "\n" )

    print( "Matrix multipication corresponds to composition of application" )
    print( "m1 @ ( m2 ( v ) ) = ( m1 @ m2 )( v )" )
    print( "{} = {}". format( m1 ( m2 ( v ) ), ( m1 @ m2 )( v ) ) )
    print( "\n" )

    print( "Determinant commutes over multiplication" )
    print( m1.determinant() * m2.determinant() - (m1 @ m2).determinant(), "\n" )    

    print( "Inveerse of matrix is indeed inverse " )
    print( m1 @ m1.inverse() )
    print( m1.inverse() @ m1, "\n" ) 


